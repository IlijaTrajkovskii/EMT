create materialized view bookings_per_host as
       select h.id as host_id, count(b.id) as num_bookings
       from hosts as h left join bookings as b on b.host_id = h.id
       group by h.id;

create materialized view hosts_per_country as
       select c.id as country_id , count(h.id) as num_hosts
       from countries as c left join hosts as h on c.id = h.country_id
       group by c.id;

