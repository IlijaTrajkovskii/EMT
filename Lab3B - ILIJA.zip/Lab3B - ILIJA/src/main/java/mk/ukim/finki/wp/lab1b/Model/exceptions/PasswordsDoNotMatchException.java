package mk.ukim.finki.wp.lab1b.Model.exceptions;

public class PasswordsDoNotMatchException extends RuntimeException{
    public PasswordsDoNotMatchException(){
        super("Passwords do not match");
    }
}
