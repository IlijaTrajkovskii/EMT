package mk.ukim.finki.wp.lab1b.Web;


import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import mk.ukim.finki.wp.lab1b.DTO.CreateHostDto;
import mk.ukim.finki.wp.lab1b.DTO.DisplayBookingDto;
import mk.ukim.finki.wp.lab1b.DTO.DisplayHostDto;
import mk.ukim.finki.wp.lab1b.Model.domain.Hosts;
import mk.ukim.finki.wp.lab1b.Model.projections.HostProjection;
import mk.ukim.finki.wp.lab1b.Model.views.HostsPerCountry;
import mk.ukim.finki.wp.lab1b.Service.application.HostApplicationService;
import mk.ukim.finki.wp.lab1b.Service.application.impl.HostApplicationServiceImpl;
import mk.ukim.finki.wp.lab1b.Service.domain.HostService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/hosts")
@Tag(name = "Host API", description = "Endpoints for managing HOSTS")
public class HostController {


    private final HostApplicationService hostApplicationService;

    public HostController(HostApplicationService hostApplicationService) {
        this.hostApplicationService = hostApplicationService;
    }


    @Operation(summary = "Get all hosts", description = "Retrieves a list of all the hosts")
    @GetMapping("/listAll")
    public ResponseEntity<List<DisplayHostDto>> listAll(){

        return ResponseEntity.ok(hostApplicationService.getAllHosts());
    }

    @PostMapping("/save")
    @Operation(summary = "Add a new host", description = "Creates a new host based on the given CreateHostDto")
    public ResponseEntity<DisplayHostDto> save(@RequestBody CreateHostDto createHostDto) throws Exception {

        return hostApplicationService.save(createHostDto)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());

    }

    @Operation(summary = "Update an existing host", description = "Updates a host by its ID using CreateHostDto")
    @PutMapping("/edit/{id}")
    public ResponseEntity<DisplayHostDto> update (@PathVariable Long id, @RequestBody CreateHostDto createHostDto) throws Exception {

        return hostApplicationService.update(id,createHostDto)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @Operation(summary = "Deletes an existing host", description = "Deletes a host by its ID")
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> delete (@PathVariable Long id) throws Exception {

        if(hostApplicationService.findById(id).isPresent()){

            hostApplicationService.deleteById(id);
            return ResponseEntity.noContent().build();
        }

         return ResponseEntity.notFound().build();
    }

    @Operation(summary = "Get number of hosts per country", description = "Retrieves a list of all the hosts per country")
    @GetMapping("/by-country")
    public ResponseEntity<List<HostsPerCountry>> getHostsPerCountry(){
        return ResponseEntity.ok(hostApplicationService.getHostsPerCountry());
    }

    @Operation(summary = "Get the names & surnames of all hosts via projection", description = "Retrieves a list of all the names and surnames of the hosts")
    @GetMapping("/names")
    public ResponseEntity<List<HostProjection>> getAllNames() {

        return ResponseEntity.ok(hostApplicationService.findHostsByNameAndSurname());
    }



}
