package mk.ukim.finki.wp.lab1b.Service.application;

import mk.ukim.finki.wp.lab1b.DTO.DisplayBookingDto;
import mk.ukim.finki.wp.lab1b.DTO.WishlistDto;

import java.util.List;
import java.util.Optional;

public interface WishlistApplicationService {

    List<DisplayBookingDto> listAllBookingsInWishlist(Long wishlistId);

    Optional<WishlistDto> getActiveWishlist(String username);

    Optional<WishlistDto> addBookingToWishlist(String username, Long bookId);

}
