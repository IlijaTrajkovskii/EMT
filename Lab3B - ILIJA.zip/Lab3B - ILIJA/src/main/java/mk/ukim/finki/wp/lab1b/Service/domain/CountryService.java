package mk.ukim.finki.wp.lab1b.Service.domain;

import mk.ukim.finki.wp.lab1b.Model.domain.Country;

import java.util.List;
import java.util.Optional;

public interface CountryService {

    List<Country> getAllCountries();
    Optional<Country> findById(Long id);
}
