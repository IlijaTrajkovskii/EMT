package mk.ukim.finki.wp.lab1b.Model.views;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;
import org.hibernate.annotations.Immutable;
import org.hibernate.annotations.Subselect;

@Data
@Entity
@Subselect("SELECT * FROM public.bookings_per_host")
@Immutable
public class BookingsPerHost {

    @Id
    @Column(name = "host_id")
    private Long hostId;

    @Column(name = "num_bookings")
    private Integer numberOfBookings;

    // DODAJ KONSTRUKTORI DA NE TE ZAEBE LOMBOK


    public BookingsPerHost() {
    }

    public BookingsPerHost(Long hostId, Integer numberOfBookings) {
        this.hostId = hostId;
        this.numberOfBookings = numberOfBookings;
    }

    public Long getHostId() {
        return hostId;
    }

    public void setHostId(Long hostId) {
        this.hostId = hostId;
    }

    public Integer getNumberOfBookings() {
        return numberOfBookings;
    }

    public void setNumberOfBookings(Integer numberOfBookings) {
        this.numberOfBookings = numberOfBookings;
    }
}
