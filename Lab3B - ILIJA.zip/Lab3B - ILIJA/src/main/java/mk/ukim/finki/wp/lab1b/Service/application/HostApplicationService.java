package mk.ukim.finki.wp.lab1b.Service.application;

import mk.ukim.finki.wp.lab1b.DTO.CreateHostDto;
import mk.ukim.finki.wp.lab1b.DTO.DisplayHostDto;
import mk.ukim.finki.wp.lab1b.Model.domain.Hosts;
import mk.ukim.finki.wp.lab1b.Model.projections.HostProjection;
import mk.ukim.finki.wp.lab1b.Model.views.HostsPerCountry;

import java.util.List;
import java.util.Optional;

public interface HostApplicationService {

    List<DisplayHostDto> getAllHosts();
    Optional<DisplayHostDto> findById(Long id);

    Optional<DisplayHostDto> save(CreateHostDto createHostDto) throws Exception;

    Optional<DisplayHostDto> update(Long id, CreateHostDto createHostDto) throws Exception;

    void deleteById(Long id) throws Exception;

    List<HostProjection> findHostsByNameAndSurname();

    List<HostsPerCountry> getHostsPerCountry();
}
