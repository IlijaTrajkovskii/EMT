package mk.ukim.finki.wp.lab1b.Repository;

import mk.ukim.finki.wp.lab1b.Model.domain.Hosts;
import mk.ukim.finki.wp.lab1b.Model.projections.HostProjection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface HostsRepository extends JpaRepository<Hosts, Long> {

    @Query("select h from Hosts h")
    List<HostProjection> findHostsByNameAndSurname();

}
