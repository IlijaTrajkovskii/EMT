package mk.ukim.finki.wp.lab1b.Model.projections;

import mk.ukim.finki.wp.lab1b.Model.domain.Country;

public interface HostProjection {
    String getName();
    String getSurname();
}
