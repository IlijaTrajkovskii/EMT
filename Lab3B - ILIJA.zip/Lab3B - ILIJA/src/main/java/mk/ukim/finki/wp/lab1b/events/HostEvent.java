package mk.ukim.finki.wp.lab1b.events;

import org.springframework.context.ApplicationEvent;

public class HostEvent extends ApplicationEvent {

    public HostEvent(Object source) {
        super(source);
    }
}
