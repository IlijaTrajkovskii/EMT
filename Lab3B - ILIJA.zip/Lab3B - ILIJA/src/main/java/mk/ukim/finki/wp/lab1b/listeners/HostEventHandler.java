package mk.ukim.finki.wp.lab1b.listeners;

import mk.ukim.finki.wp.lab1b.Service.domain.HostService;
import mk.ukim.finki.wp.lab1b.events.HostEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component
public class HostEventHandler {

    private final HostService hostService;

    public HostEventHandler(HostService hostService) {
        this.hostService = hostService;
    }

    // za da bide za klasata HostEvent

    @EventListener(HostEvent.class)
    public void refreshMaterializedView()
    {
        hostService.refreshMaterializedView();
    }
}
