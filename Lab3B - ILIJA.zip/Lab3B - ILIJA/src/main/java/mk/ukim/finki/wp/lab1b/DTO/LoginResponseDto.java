package mk.ukim.finki.wp.lab1b.DTO;

public record LoginResponseDto(
        String token
) {
}
