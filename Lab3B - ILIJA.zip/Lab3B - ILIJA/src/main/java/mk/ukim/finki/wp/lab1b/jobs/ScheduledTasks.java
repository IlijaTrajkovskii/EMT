package mk.ukim.finki.wp.lab1b.jobs;

import mk.ukim.finki.wp.lab1b.Service.domain.BookingService;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

//za avtomatski da se updatene
@Component
public class ScheduledTasks {

     // materialized view во рамките на базата на податоци којшто ќе се ажурира СЕКОЈ ДЕН !!!
    private final BookingService bookingService;

    public ScheduledTasks(BookingService bookingService)
    {
        this.bookingService = bookingService;
    }

    // се ажурира секој ден автоматски  vo slucajov na minuta e
    @Scheduled(cron = "0 * * * * *")
    public void refreshMaterializedView() {
        bookingService.refreshMaterializedView();
    }

}
