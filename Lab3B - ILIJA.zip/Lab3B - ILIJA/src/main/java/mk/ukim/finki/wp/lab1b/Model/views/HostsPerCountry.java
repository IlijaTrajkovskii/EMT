package mk.ukim.finki.wp.lab1b.Model.views;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;
import org.hibernate.annotations.Immutable;
import org.hibernate.annotations.Subselect;

@Data
@Entity
@Subselect("SELECT * FROM public.hosts_per_country")
@Immutable
public class HostsPerCountry {

    @Id
    @Column(name = "country_id")
    private Long countryId;

    @Column(name = "num_hosts")
    private Integer numberOfHosts;

    public HostsPerCountry() {
    }

    public HostsPerCountry(Long countryId, Integer numberOfHosts) {
        this.countryId = countryId;
        this.numberOfHosts = numberOfHosts;
    }

    public Long getCountryId() {
        return countryId;
    }

    public void setCountryId(Long countryId) {
        this.countryId = countryId;
    }

    public Integer getNumberOfHosts() {
        return numberOfHosts;
    }

    public void setNumberOfHosts(Integer numberOfHosts) {
        this.numberOfHosts = numberOfHosts;
    }
}
