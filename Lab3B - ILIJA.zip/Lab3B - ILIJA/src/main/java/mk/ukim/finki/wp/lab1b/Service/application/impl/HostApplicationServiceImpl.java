package mk.ukim.finki.wp.lab1b.Service.application.impl;


import mk.ukim.finki.wp.lab1b.DTO.CreateHostDto;
import mk.ukim.finki.wp.lab1b.DTO.DisplayHostDto;
import mk.ukim.finki.wp.lab1b.Model.domain.Country;
import mk.ukim.finki.wp.lab1b.Model.domain.Hosts;
import mk.ukim.finki.wp.lab1b.Model.projections.HostProjection;
import mk.ukim.finki.wp.lab1b.Model.views.HostsPerCountry;
import mk.ukim.finki.wp.lab1b.Repository.HostsRepository;
import mk.ukim.finki.wp.lab1b.Service.application.HostApplicationService;
import mk.ukim.finki.wp.lab1b.Service.domain.CountryService;
import mk.ukim.finki.wp.lab1b.Service.domain.HostService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class HostApplicationServiceImpl implements HostApplicationService {

    private final HostService hostService;
    private final CountryService countryService;

    public HostApplicationServiceImpl(HostService hostService, CountryService countryService) {
        this.hostService = hostService;
        this.countryService = countryService;
    }

    @Override
    public List<DisplayHostDto> getAllHosts() {
        return hostService.getAllHosts().stream().map(DisplayHostDto::fromHost).toList();
    }

    @Override
    public Optional<DisplayHostDto> findById(Long id) {
        return hostService.findById(id).map(DisplayHostDto::fromHost);
    }

    @Override
    public Optional<DisplayHostDto> save(CreateHostDto createHostDto) throws Exception {

        Optional<Country> country = countryService.findById(createHostDto.countryId());

        if(country.isPresent()) {
//            1 nachin
//            return hostService.save(
//                    new Hosts(
//                            createHostDto.name(),
//                            createHostDto.surname(),
//                            country.get()
//                    )
//            ).map(DisplayHostDto::fromHost);

            return hostService.save(createHostDto.toHost(country.get())).map(DisplayHostDto::fromHost);

        } else {
            return Optional.empty();
        }
    }

    @Override
    public Optional<DisplayHostDto> update(Long id, CreateHostDto createHostDto) throws Exception {


        Optional<Country> country = countryService.findById(createHostDto.countryId());

        return hostService.update(id,createHostDto.toHost(country.get())).map(DisplayHostDto::fromHost);


    }

    @Override
    public void deleteById(Long id) throws Exception {
        hostService.deleteById(id);
    }


    @Override
    public List<HostProjection> findHostsByNameAndSurname() {
        return hostService.findHostsByNameAndSurname();
    }

    @Override
    public List<HostsPerCountry> getHostsPerCountry() {
        return hostService.getHostsPerCountry();
    }
}
