package mk.ukim.finki.wp.lab1b.DTO;

import mk.ukim.finki.wp.lab1b.Model.domain.Country;
import mk.ukim.finki.wp.lab1b.Model.domain.Hosts;

import java.util.List;
import java.util.stream.Collectors;

public record DisplayHostDto(
        Long id,
        String name,
        String surname,
        Long countryId) {

    public static DisplayHostDto fromHost(Hosts host) {
        return new DisplayHostDto(
                host.getId(),
                host.getName(),
                host.getSurname(),
                host.getCountry().getId()
        );
    }

    public static List<DisplayHostDto> fromHost(List<Hosts> hosts) {
       return hosts.stream().map(DisplayHostDto::fromHost).collect(Collectors.toList());
    }

    public Hosts toHost(Country country) {
        return new Hosts(name, surname, country);
    }

}
