package mk.ukim.finki.wp.lab1b.Service.domain;

import mk.ukim.finki.wp.lab1b.Model.domain.Booking;

import java.util.List;
import java.util.Optional;

public interface BookingService {

    List<Booking> getAllBookings();
    Optional<Booking> findById(Long id);

    Optional<Booking> update(Long id, Booking booking) throws Exception;

    Optional<Booking> save(Booking booking) throws Exception;

    void deleteById(Long id);

    void rented(Long id) throws Exception;


}
