package mk.ukim.finki.wp.lab1b.Web;


import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import mk.ukim.finki.wp.lab1b.DTO.CreateBookingDto;
import mk.ukim.finki.wp.lab1b.DTO.DisplayBookingDto;
import mk.ukim.finki.wp.lab1b.Model.domain.Booking;
import mk.ukim.finki.wp.lab1b.Service.application.BookingApplicationService;
import mk.ukim.finki.wp.lab1b.Service.domain.BookingService;
import mk.ukim.finki.wp.lab1b.Service.domain.HostService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bookings")
@Tag(name = "Booking API", description = "Endpoints for managing BOOKINGS")
public class BookingController {

    private final BookingApplicationService bookingApplicationService;

    public BookingController(BookingApplicationService bookingApplicationService) {
        this.bookingApplicationService = bookingApplicationService;
    }

    //------------------//


    @Operation(summary = "Get all Bookings", description = "Retrieves a list of all available bookings made")
    @GetMapping("/listAll")
    public ResponseEntity<List<DisplayBookingDto>> listAll(){

        return ResponseEntity.ok(bookingApplicationService.getAllBookings());
    }

    @Operation(summary = "Get booking by ID", description = "Finds and retrieves the booking by its ID")
    @GetMapping("/{id}")
    public ResponseEntity<DisplayBookingDto> findById(@PathVariable Long id) throws Exception {

        return bookingApplicationService.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());


    }

    @Operation(summary = "Add a new booking", description = "Creates a new booking based on the given BookingDto")
    @PostMapping("/save")
    public ResponseEntity<DisplayBookingDto> save(@RequestBody CreateBookingDto createBookingDto) throws Exception {

        return bookingApplicationService.save(createBookingDto)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @Operation(summary = "Update an existing booking", description = "Updates a booking by its ID using BookingDto")
    @PutMapping("/edit/{id}")
    public ResponseEntity<DisplayBookingDto> update(@PathVariable Long id, @RequestBody CreateBookingDto createBookingDto) throws Exception {

        return bookingApplicationService.update(id,createBookingDto)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @Operation(summary = "Rent a booking", description = "Rents the booking, setting it's availability as well")
    @PutMapping("/rent/{id}")
    public ResponseEntity<DisplayBookingDto> rent(@PathVariable Long id) throws Exception {

        bookingApplicationService.rented(id);

        return ResponseEntity.noContent().build();

    }

    @Operation(summary = "Deletes an existing booking", description = "Deletes a product by its ID")
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) throws Exception {

       if(bookingApplicationService.findById(id).isPresent()){

           bookingApplicationService.deleteById(id);
           return ResponseEntity.noContent().build();
       }

        return ResponseEntity.notFound().build();
    }



}
