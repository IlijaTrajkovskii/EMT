package mk.ukim.finki.wp.lab1b.Repository;

import mk.ukim.finki.wp.lab1b.Model.domain.Booking;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BookingRepository extends JpaRepository<Booking, Long> {
}
