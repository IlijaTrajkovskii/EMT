package mk.ukim.finki.wp.lab1b.Service.application;

import mk.ukim.finki.wp.lab1b.DTO.CreateBookingDto;
import mk.ukim.finki.wp.lab1b.DTO.DisplayBookingDto;
import mk.ukim.finki.wp.lab1b.Model.domain.Booking;

import java.util.List;
import java.util.Optional;

public interface BookingApplicationService {

    List<DisplayBookingDto> getAllBookings();
    Optional<DisplayBookingDto> findById(Long id);

    Optional<DisplayBookingDto> update(Long id, CreateBookingDto createBookingDto) throws Exception;

    Optional<DisplayBookingDto> save(CreateBookingDto createBookingDto) throws Exception;

    void deleteById(Long id);

    void rented(Long id) throws Exception;


}
