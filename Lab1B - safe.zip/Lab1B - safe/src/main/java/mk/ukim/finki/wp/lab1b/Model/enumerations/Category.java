package mk.ukim.finki.wp.lab1b.Model.enumerations;

public enum Category {
    ROOM,
    HOUSE,
    FLAT,
    APARTMENT,
    HOTEL,
    MOTEL
}
