package mk.ukim.finki.wp.lab1b.Service.application.impl;


import mk.ukim.finki.wp.lab1b.DTO.DisplayCountryDto;
import mk.ukim.finki.wp.lab1b.Model.domain.Country;
import mk.ukim.finki.wp.lab1b.Repository.CountryRepository;
import mk.ukim.finki.wp.lab1b.Service.application.CountryApplicationService;
import mk.ukim.finki.wp.lab1b.Service.domain.CountryService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CountryApplicationServiceImpl implements CountryApplicationService {

    private final CountryService countryService;

    public CountryApplicationServiceImpl(CountryService countryService) {
        this.countryService = countryService;
    }

    @Override
    public List<DisplayCountryDto> getAllCountries() {
        return countryService.getAllCountries().stream().map(DisplayCountryDto::fromCountry).toList();
    }

    @Override
    public Optional<DisplayCountryDto> findById(Long id) {
        return countryService.findById(id).map(DisplayCountryDto::fromCountry);
    }
}
