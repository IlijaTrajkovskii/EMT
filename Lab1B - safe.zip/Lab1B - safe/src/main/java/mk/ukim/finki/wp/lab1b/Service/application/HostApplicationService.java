package mk.ukim.finki.wp.lab1b.Service.application;

import mk.ukim.finki.wp.lab1b.DTO.DisplayHostDto;
import mk.ukim.finki.wp.lab1b.Model.domain.Hosts;

import java.util.List;
import java.util.Optional;

public interface HostApplicationService {

    List<DisplayHostDto> getAllHosts();
    Optional<DisplayHostDto> findById(Long id);
}
