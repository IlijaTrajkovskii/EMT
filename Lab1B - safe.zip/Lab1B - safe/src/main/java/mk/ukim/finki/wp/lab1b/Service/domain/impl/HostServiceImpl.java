package mk.ukim.finki.wp.lab1b.Service.domain.impl;


import mk.ukim.finki.wp.lab1b.Model.domain.Hosts;
import mk.ukim.finki.wp.lab1b.Repository.HostsRepository;
import mk.ukim.finki.wp.lab1b.Service.domain.HostService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class HostServiceImpl implements HostService {

    private final HostsRepository hostsRepository;

    public HostServiceImpl(HostsRepository hostsRepository) {
        this.hostsRepository = hostsRepository;
    }

    @Override
    public List<Hosts> getAllHosts() {
        return hostsRepository.findAll();
    }

    @Override
    public Optional<Hosts> findById(Long id) {
        return hostsRepository.findById(id);
    }
}
