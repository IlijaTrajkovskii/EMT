package mk.ukim.finki.wp.lab1b.Model.domain;

import jakarta.persistence.*;
import lombok.Data;
import mk.ukim.finki.wp.lab1b.Model.enumerations.Category;

@Data
@Entity
@Table(name = "bookings")
public class Booking {


    @Id
    @GeneratedValue
    private Long id;

    private String name;
    private Category category; //enum

    @ManyToOne
    private Hosts hosts;

    private Integer numRooms;
    private Boolean rented = false;


    public Booking() {
    }

    public Booking(String name, Category category, Hosts hosts, Integer numRooms) {
        this.name = name;
        this.category = category;
        this.hosts = hosts;
        this.numRooms = numRooms;

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public Hosts getHosts() {
        return hosts;
    }

    public void setHosts(Hosts hosts) {
        this.hosts = hosts;
    }

    public Integer getNumRooms() {
        return numRooms;
    }

    public void setNumRooms(Integer numRooms) {
        this.numRooms = numRooms;
    }

    public Boolean getRented() {
        return rented;
    }

    public void setRented(Boolean rented) {
        this.rented = rented;
    }
}
