package mk.ukim.finki.wp.lab1b.Web;


import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import mk.ukim.finki.wp.lab1b.DTO.DisplayBookingDto;
import mk.ukim.finki.wp.lab1b.DTO.DisplayCountryDto;
import mk.ukim.finki.wp.lab1b.Service.application.CountryApplicationService;
import mk.ukim.finki.wp.lab1b.Service.application.impl.CountryApplicationServiceImpl;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/countries")
@Tag(name = "Country API", description = "Endpoints for managing COUNTRIES")
public class CountryController {

    private final CountryApplicationService countryApplicationService;

    public CountryController(CountryApplicationService countryApplicationService) {
        this.countryApplicationService = countryApplicationService;
    }

    @Operation(summary = "Get all countries", description = "Retrieves a list of all available countries ")
    @GetMapping("/listAll")
    public ResponseEntity<List<DisplayCountryDto>> listAll(){

        return ResponseEntity.ok(countryApplicationService.getAllCountries());
    }
}










