package mk.ukim.finki.wp.lab1b.DTO;

import mk.ukim.finki.wp.lab1b.Model.domain.Booking;
import mk.ukim.finki.wp.lab1b.Model.domain.Hosts;
import mk.ukim.finki.wp.lab1b.Model.enumerations.Category;
import org.springframework.data.relational.core.sql.In;

import java.util.List;
import java.util.stream.Collectors;

public record DisplayBookingDto(
        Long id,
        String name,
        Category category,
        Long hostId,
        Integer numRooms,
        Boolean rented
        ) {

    public static DisplayBookingDto fromBooking(Booking booking) {
        return new DisplayBookingDto(
                booking.getId(),
                booking.getName(),
                booking.getCategory(),
                booking.getHosts().getId(),
                booking.getNumRooms(),
                booking.getRented()
        );
    }

    public static List<DisplayBookingDto> fromBooking(List<Booking> bookings) {
        return bookings.stream().map(DisplayBookingDto::fromBooking).collect(Collectors.toList());
    }

    public Booking toBooking(Hosts host) {
        return new Booking(name, category ,host,numRooms);
    }
}
