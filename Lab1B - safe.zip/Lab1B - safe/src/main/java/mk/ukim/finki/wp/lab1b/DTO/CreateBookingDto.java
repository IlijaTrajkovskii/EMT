package mk.ukim.finki.wp.lab1b.DTO;

import mk.ukim.finki.wp.lab1b.Model.domain.Booking;
import mk.ukim.finki.wp.lab1b.Model.domain.Hosts;
import mk.ukim.finki.wp.lab1b.Model.enumerations.Category;

import java.util.List;
import java.util.stream.Collectors;

public record CreateBookingDto(
        String name,
        Category category, //enum
        Long hostId,
        Integer numRooms,
        Boolean rented) {

    // znachi dto koristime za komunikacija megju controler i domain

    public static CreateBookingDto fromBooking(Booking booking) {

        return new CreateBookingDto(
                booking.getName(),
                booking.getCategory(),
                booking.getHosts().getId(),
                booking.getNumRooms(),
                booking.getRented()

        );
    }

    public static List<CreateBookingDto> fromBooking(List<Booking> bookings) {
        return bookings.stream().map(CreateBookingDto::fromBooking).collect(Collectors.toList());
    }

    public Booking toBooking(Hosts host) {
        return new Booking(name,category,host,numRooms);
    }
}
