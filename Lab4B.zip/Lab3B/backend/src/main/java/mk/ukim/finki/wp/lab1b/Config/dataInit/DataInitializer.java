package mk.ukim.finki.wp.lab1b.Config.dataInit;


import jakarta.annotation.PostConstruct;
import mk.ukim.finki.wp.lab1b.Model.domain.Country;
import mk.ukim.finki.wp.lab1b.Model.domain.Hosts;
import mk.ukim.finki.wp.lab1b.Model.domain.User;
import mk.ukim.finki.wp.lab1b.Model.enumerations.Role;
import mk.ukim.finki.wp.lab1b.Repository.CountryRepository;
import mk.ukim.finki.wp.lab1b.Repository.HostsRepository;
import mk.ukim.finki.wp.lab1b.Repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer {

    private final HostsRepository hostsRepository;
    private final CountryRepository countryRepository;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;


    public DataInitializer(HostsRepository hostsRepository, CountryRepository countryRepository, UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.hostsRepository = hostsRepository;
        this.countryRepository = countryRepository;
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

  //  @PostConstruct
    public void DataInit() {
        Country macedonia = new Country( "Macedonia", "Europe");
        Country usa = new Country( "USA", "North America");

       countryRepository.save(macedonia);
       countryRepository.save(usa);

        hostsRepository.save(new Hosts( "Ivan", "Ivanov", macedonia));
        hostsRepository.save(new Hosts( "John", "Doe", usa));

        userRepository.save(new User(
                "admin",
                passwordEncoder.encode("admin"),
                "Ilija",
                "Trajkovski",
                Role.ROLE_HOST // so uloga host
        ));

        userRepository.save(new User(
                "user",
                passwordEncoder.encode("user"),
                "user",
                "user",
                Role.ROLE_USER
        ));

    }


}
