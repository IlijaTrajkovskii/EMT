package mk.ukim.finki.wp.lab1b.Service.domain.impl;


import mk.ukim.finki.wp.lab1b.Model.domain.Country;
import mk.ukim.finki.wp.lab1b.Repository.CountryRepository;
import mk.ukim.finki.wp.lab1b.Service.domain.CountryService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CountryServiceImpl implements CountryService {

    private final CountryRepository countryRepository;

    public CountryServiceImpl(CountryRepository countryRepository) {
        this.countryRepository = countryRepository;
    }

    @Override
    public List<Country> getAllCountries() {
        return countryRepository.findAll();
    }

    @Override
    public Optional<Country> findById(Long id) {
        return countryRepository.findById(id);
    }

    @Override
    public Optional<Country> add(Country country) {
        return Optional.of(countryRepository.save(country));
    }

    @Override
    public Optional<Country> update(Long id, Country country) {
        Optional<Country> countryEntityOptional = findById(id);

        if (countryEntityOptional.isPresent()) {
            Country countryEntity = countryEntityOptional.get();

            if (country.getName() != null) {
                countryEntity.setName(country.getName());
            }

            if (country.getContinent() != null) {
                countryEntity.setContinent(country.getContinent());
            }

            return Optional.of(countryRepository.save(countryEntity));
        } else {
            return Optional.empty();
        }
    }

    @Override
    public void delete(Long id) {
        countryRepository.deleteById(id);
    }
}
