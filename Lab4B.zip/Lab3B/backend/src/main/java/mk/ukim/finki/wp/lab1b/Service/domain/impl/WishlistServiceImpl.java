package mk.ukim.finki.wp.lab1b.Service.domain.impl;

import mk.ukim.finki.wp.lab1b.Model.domain.Booking;
import mk.ukim.finki.wp.lab1b.Model.domain.User;
import mk.ukim.finki.wp.lab1b.Model.domain.Wishlist;
import mk.ukim.finki.wp.lab1b.Model.exceptions.BookingAlreadyInWishlistException;
import mk.ukim.finki.wp.lab1b.Model.exceptions.BookingNotFoundException;
import mk.ukim.finki.wp.lab1b.Model.exceptions.WishlistNotFoundException;
import mk.ukim.finki.wp.lab1b.Repository.WishlistRepository;
import mk.ukim.finki.wp.lab1b.Service.domain.BookingService;
import mk.ukim.finki.wp.lab1b.Service.domain.UserService;
import mk.ukim.finki.wp.lab1b.Service.domain.WishlistService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
public class WishlistServiceImpl implements WishlistService {

    private final WishlistRepository wishlistRepository;
    private final UserService userService;
    private final BookingService bookingService;


    public WishlistServiceImpl(WishlistRepository wishlistRepository, UserService userService, BookingService bookingService) {
        this.wishlistRepository = wishlistRepository;
        this.userService = userService;
        this.bookingService = bookingService;
    }

    @Override
    public List<Booking> listAllBookingsInWishlist(Long wishlistId) {
        if (wishlistRepository.findById(wishlistId).isEmpty())
            throw new WishlistNotFoundException(wishlistId);
        return wishlistRepository.findById(wishlistId).get().getBookings();
    }

    @Override
    public Optional<Wishlist> getActiveWishlist(String username) {
        User user = userService.findByUsername(username);

        return Optional.of(wishlistRepository.findByUser(user)
                .orElseGet(() -> wishlistRepository.save(new Wishlist(user))));
    }

    @Override
    public Optional<Wishlist> addBookingToWishlist(String username, Long bookingId) {
        if (getActiveWishlist(username).isPresent()) {
            Wishlist wishlist = getActiveWishlist(username).get();

            Booking booking = bookingService.findById(bookingId)
                    .orElseThrow(() -> new BookingNotFoundException(bookingId));
            if (!wishlist.getBookings().stream().filter(i -> i.getId().equals(bookingId)).toList().isEmpty())
                throw new BookingAlreadyInWishlistException(bookingId, username);
            wishlist.getBookings().add(booking);
            return Optional.of(wishlistRepository.save(wishlist));
        }
        return Optional.empty();
    }
}
