package mk.ukim.finki.wp.lab1b.Service.application;

import mk.ukim.finki.wp.lab1b.DTO.CreateCountryDto;
import mk.ukim.finki.wp.lab1b.DTO.DisplayCountryDto;
import mk.ukim.finki.wp.lab1b.Model.domain.Country;

import java.util.List;
import java.util.Optional;

public interface CountryApplicationService {

    List<DisplayCountryDto> getAllCountries();
    Optional<DisplayCountryDto> findById(Long id);
    Optional<DisplayCountryDto> add(CreateCountryDto createCountryDto);
    Optional<DisplayCountryDto> update(Long id, CreateCountryDto createCountryDto);
    void delete(Long id);
}
