package mk.ukim.finki.wp.lab1b.DTO;

import mk.ukim.finki.wp.lab1b.Model.domain.Wishlist;

import java.time.LocalDateTime;
import java.util.List;

public record WishlistDto(
        Long id,
        LocalDateTime dateCreated,
        DisplayUserDto user,
        List<DisplayBookingDto> bookings
) {

    public static WishlistDto fromWishlist(Wishlist wishlist) {
        return new WishlistDto(
                wishlist.getId(),
                wishlist.getDateCreated(),
                DisplayUserDto.from(wishlist.getUser()),
                DisplayBookingDto.fromBooking(wishlist.getBookings())
        );
    }

}
