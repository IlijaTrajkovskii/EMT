package mk.ukim.finki.wp.lab1b.DTO;

import mk.ukim.finki.wp.lab1b.Model.domain.Country;
import mk.ukim.finki.wp.lab1b.Model.domain.Hosts;

import java.util.List;
import java.util.stream.Collectors;

public record CreateHostDto(
        String name,
        String surname,
        Long countryId) {

    public static CreateHostDto fromHost(Hosts host){
        return new CreateHostDto(
                host.getName(),
                host.getSurname(),
                host.getCountry().getId()
        );
    }

    public static List<CreateHostDto> fromHost(List<Hosts> hosts){
        return hosts.stream().map(CreateHostDto::fromHost).collect(Collectors.toList());
    }

    public Hosts toHost(Country country){
        return new Hosts(name,surname,country);
    }

}
