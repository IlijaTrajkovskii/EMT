package mk.ukim.finki.wp.lab1b.Web;


import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import mk.ukim.finki.wp.lab1b.DTO.CreateBookingDto;
import mk.ukim.finki.wp.lab1b.DTO.CreateCountryDto;
import mk.ukim.finki.wp.lab1b.DTO.DisplayBookingDto;
import mk.ukim.finki.wp.lab1b.DTO.DisplayCountryDto;
import mk.ukim.finki.wp.lab1b.Service.application.CountryApplicationService;
import mk.ukim.finki.wp.lab1b.Service.application.impl.CountryApplicationServiceImpl;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/countries")
@Tag(name = "Country API", description = "Endpoints for managing COUNTRIES")
public class CountryController {

    private final CountryApplicationService countryApplicationService;

    public CountryController(CountryApplicationService countryApplicationService) {
        this.countryApplicationService = countryApplicationService;
    }

    @Operation(summary = "Get all countries", description = "Retrieves a list of all available countries ")
    @GetMapping("/listAll")
    public ResponseEntity<List<DisplayCountryDto>> listAll(){

        return ResponseEntity.ok(countryApplicationService.getAllCountries());
    }

    @PostMapping("/save")
    public ResponseEntity<DisplayCountryDto> add(@RequestBody CreateCountryDto createCountryDto) {
        return ResponseEntity.ok(countryApplicationService.add(createCountryDto).get());
    }


    @PutMapping("/edit/{id}")
    public ResponseEntity<DisplayCountryDto> update(@PathVariable Long id, @RequestBody CreateCountryDto createCountryDto) {
        return ResponseEntity.ok(countryApplicationService.update(id, createCountryDto).get());
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        countryApplicationService.delete(id);
        return ResponseEntity.noContent().build();
    }
}










