package mk.ukim.finki.wp.lab1b.Service.application.impl;

import mk.ukim.finki.wp.lab1b.Config.jwt.JwtHelper;
import mk.ukim.finki.wp.lab1b.DTO.CreateUserDto;
import mk.ukim.finki.wp.lab1b.DTO.DisplayUserDto;
import mk.ukim.finki.wp.lab1b.DTO.LoginResponseDto;
import mk.ukim.finki.wp.lab1b.DTO.LoginUserDto;
import mk.ukim.finki.wp.lab1b.Model.domain.User;
import mk.ukim.finki.wp.lab1b.Service.application.UserApplicationService;
import mk.ukim.finki.wp.lab1b.Service.domain.UserService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserApplicationServiceImpl implements UserApplicationService {

    // tuka sme veke vo aplikaciski sloj i povikuvame domenski servis

    private final UserService userService;
    private final JwtHelper jwtHelper;

    public UserApplicationServiceImpl(UserService userService, JwtHelper jwtHelper) {
        this.userService = userService;
        this.jwtHelper = jwtHelper;
    }

    @Override
    public List<DisplayUserDto> findAll() {
        return userService.findAll().stream().map(DisplayUserDto::from).toList();
    }

    @Override
    public Optional<DisplayUserDto> register(CreateUserDto createUserDto) {

        User user = userService.register(
                createUserDto.username(),
                createUserDto.password(),
                createUserDto.repeatPassword(),
                createUserDto.name(),
                createUserDto.surname(),
                createUserDto.role()
        );
        return Optional.of(DisplayUserDto.from(user));


    }

    @Override
    public Optional<LoginResponseDto> login(LoginUserDto loginUserDto) {

       User user = userService.login(loginUserDto.username(), loginUserDto.password());

       String token = jwtHelper.generateToken(user);

       //na vakov nacin se vraka jwt tokenot pri login
       return Optional.of(new LoginResponseDto(token));


    }

    @Override
    public Optional<DisplayUserDto> findByUsername(String username) {
        return Optional.of(DisplayUserDto.from(userService.findByUsername(username)));
    }
}
