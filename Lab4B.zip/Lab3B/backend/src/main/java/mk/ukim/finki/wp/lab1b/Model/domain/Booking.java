package mk.ukim.finki.wp.lab1b.Model.domain;

import jakarta.persistence.*;
import lombok.Data;
import mk.ukim.finki.wp.lab1b.Model.enumerations.Category;

@Data
@Entity
@Table(name = "bookings")
public class Booking {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private Category category; //enum

    @ManyToOne
 //   @JoinColumn(name = "host_id") ili reimenuvaj vo host
    private Hosts host;

    @Column(name = "num_rooms")
    private Integer numRooms;
    private Boolean rented = false;


    public Booking() {
    }

    public Booking(String name, Category category, Hosts host, Integer numRooms) {
        this.name = name;
        this.category = category;
        this.host = host;
        this.numRooms = numRooms;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public Hosts getHost() {
        return host;
    }

    public void setHost(Hosts host) {
        this.host = host;
    }

    public Integer getNumRooms() {
        return numRooms;
    }

    public void setNumRooms(Integer numRooms) {
        this.numRooms = numRooms;
    }

    public Boolean getRented() {
        return rented;
    }

    public void setRented(Boolean rented) {
        this.rented = rented;
    }
}
