package mk.ukim.finki.wp.lab1b.Service.domain.impl;


import mk.ukim.finki.wp.lab1b.Model.domain.Country;
import mk.ukim.finki.wp.lab1b.Model.domain.Hosts;
import mk.ukim.finki.wp.lab1b.Model.projections.HostProjection;
import mk.ukim.finki.wp.lab1b.Model.views.HostsPerCountry;
import mk.ukim.finki.wp.lab1b.Repository.CountryRepository;
import mk.ukim.finki.wp.lab1b.Repository.HostsPerCountryRepository;
import mk.ukim.finki.wp.lab1b.Repository.HostsRepository;
import mk.ukim.finki.wp.lab1b.Service.domain.HostService;
import mk.ukim.finki.wp.lab1b.events.HostEvent;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class HostServiceImpl implements HostService {

    private final HostsRepository hostsRepository;
    private final CountryRepository countryRepository;
    private final HostsPerCountryRepository hostsPerCountryRepository;
    private final ApplicationEventPublisher eventPublisher;  //MNOGU BITNO ZA EVENTS


    public HostServiceImpl(HostsRepository hostsRepository, CountryRepository countryRepository, HostsPerCountryRepository hostsPerCountryRepository, ApplicationEventPublisher eventPublisher) {
        this.hostsRepository = hostsRepository;
        this.countryRepository = countryRepository;
        this.hostsPerCountryRepository = hostsPerCountryRepository;
        this.eventPublisher = eventPublisher;
    }

    @Override
    public List<Hosts> getAllHosts() {
        return hostsRepository.findAll();
    }

    @Override
    public Optional<Hosts> findById(Long id) {
        return hostsRepository.findById(id);
    }

    @Override
    public Optional<Hosts> save(Hosts host) {

        Hosts hostSaved = hostsRepository.save(host);

        HostEvent hostEvent = new HostEvent(host);
        eventPublisher.publishEvent(hostEvent); //vaka VIEW se azurira posle save()

        return Optional.of(hostSaved);

    }

    @Override
    public Optional<Hosts> update(Long id,Hosts host) throws Exception {

        //prvicno go naogjame hostot koj sto ke go edituvame
        Hosts existingHost = hostsRepository.findById(id).orElseThrow(Exception::new);

        //potoa ja naogjame od edituvaniot objekt drzavata
        Country country = countryRepository.findById(host.getCountry().getId()).orElseThrow(Exception::new);

        if (host.getName() != null) {
            existingHost.setName(host.getName());
        }
        if(host.getSurname() != null) {
            existingHost.setSurname(host.getSurname());
        }
        if(host.getCountry() != null) {
            existingHost.setCountry(country);
        }

        Hosts updatedHost = hostsRepository.save(existingHost);

        HostEvent hostEvent = new HostEvent(updatedHost); //azuriranje VIEW
        eventPublisher.publishEvent(hostEvent);


        return Optional.of(updatedHost);


    }

    @Override
    public void deleteById(Long id) throws Exception {

      Hosts deletedHost = hostsRepository.findById(id).orElseThrow(Exception::new);

      hostsRepository.deleteById(id);

      HostEvent hostEvent = new HostEvent(deletedHost); //azuriranje VIEW
      eventPublisher.publishEvent(hostEvent);
    }



    @Override
    public void refreshMaterializedView() {
        hostsPerCountryRepository.refreshMaterializedView();
    }

    @Override
    public List<HostProjection> findHostsByNameAndSurname() {
        return hostsRepository.findHostsByNameAndSurname();
    }

    @Override
    public List<HostsPerCountry> getHostsPerCountry() {
        return hostsPerCountryRepository.findAll();
    }
}
