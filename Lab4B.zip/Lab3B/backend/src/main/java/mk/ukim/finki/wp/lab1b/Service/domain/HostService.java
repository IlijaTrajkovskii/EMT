package mk.ukim.finki.wp.lab1b.Service.domain;

import mk.ukim.finki.wp.lab1b.Model.domain.Hosts;
import mk.ukim.finki.wp.lab1b.Model.projections.HostProjection;
import mk.ukim.finki.wp.lab1b.Model.views.HostsPerCountry;

import java.util.List;
import java.util.Optional;

public interface HostService {

    List<Hosts> getAllHosts();
    Optional<Hosts> findById(Long id);

    Optional<Hosts> save(Hosts host);

    Optional<Hosts> update(Long id,Hosts host) throws Exception;

    void deleteById(Long id) throws Exception;

    void refreshMaterializedView();

    List<HostsPerCountry> getHostsPerCountry();

    List<HostProjection> findHostsByNameAndSurname();
}
