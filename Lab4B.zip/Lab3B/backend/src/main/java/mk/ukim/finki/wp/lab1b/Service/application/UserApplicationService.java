package mk.ukim.finki.wp.lab1b.Service.application;

import mk.ukim.finki.wp.lab1b.DTO.CreateUserDto;
import mk.ukim.finki.wp.lab1b.DTO.DisplayUserDto;
import mk.ukim.finki.wp.lab1b.DTO.LoginResponseDto;
import mk.ukim.finki.wp.lab1b.DTO.LoginUserDto;

import java.util.List;
import java.util.Optional;

public interface UserApplicationService {

    Optional<DisplayUserDto> register(CreateUserDto createUserDto);

    Optional<LoginResponseDto> login(LoginUserDto loginUserDto);

    Optional<DisplayUserDto> findByUsername(String username);

    List<DisplayUserDto> findAll();


}
