import React from "react";
import LoginForm from "../components/login/LoginForm";

const LoginPage = () => {
    return (
        <div>
            <p>Please log in to continue</p>
            <LoginForm />
        </div>
    );
};

export default LoginPage;
