import { Button, Container, Typography } from "@mui/material";
import { useState } from "react";
import BookingForm from "../components/booking/BookingForm";
import BookingList from "../components/booking/BookingList";
import ConfirmDialog from "../components/shared/ConfirmDialog";
import useBookings from "../hooks/useBookings";
import useHosts from "../hooks/useHosts"; // Hook for fetching hosts

const BookingPage = () => {
    const { bookings, loading, onAdd, onEdit, onDelete } = useBookings();
    const { hosts } = useHosts(); // Fetch hosts for the dropdown
    const [showForm, setShowForm] = useState(false);
    const [editing, setEditing] = useState(null);
    const [confirmDelete, setConfirmDelete] = useState(null);

    const handleAdd = () => {
        setEditing(null);
        setShowForm(true);
    };

    const handleSubmit = async (data) => {
        if (editing) {
            onEdit(editing.id, data);
        } else {
            onAdd(data);
        }
        setShowForm(false);
        setEditing(null);
    };

    const handleDelete = async () => {
        onDelete(confirmDelete.id);
        setConfirmDelete(null);
    };

    return (
        <Container sx={{ mt: 4 }}>
            <Typography variant="h4" gutterBottom>
                Manage Bookings
            </Typography>
            <Button variant="contained" color="primary" onClick={handleAdd}>
                Add Booking
            </Button>

            {!loading && (
                <BookingList
                    bookings={bookings}
                    onEdit={(item) => {
                        setEditing(item);
                        setShowForm(true);
                    }}
                    onDelete={(item) => setConfirmDelete(item)}
                />
            )}

            <BookingForm
                open={showForm}
                onClose={() => {
                    setShowForm(false);
                    setEditing(null);
                }}
                onSubmit={handleSubmit}
                initialData={editing}
                hosts={hosts} // Pass hosts to the form
            />

            <ConfirmDialog
                open={!!confirmDelete}
                title="Delete Booking"
                content={`Are you sure you want to delete "${confirmDelete?.name}"?`}
                onClose={() => setConfirmDelete(null)}
                onConfirm={handleDelete}
            />
        </Container>
    );
};

export default BookingPage;
