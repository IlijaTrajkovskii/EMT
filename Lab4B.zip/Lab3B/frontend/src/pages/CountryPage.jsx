import { Button, Container, Typography } from "@mui/material";
import { useState } from "react";
import CountryForm from "../components/country/CountryForm";
import CountryList from "../components/country/CountryList";
import ConfirmDialog from "../components/shared/ConfirmDialog";
import useCountries from "../hooks/useCountries";

const CountryPage = () => {
    const { countries, loading, onAdd, onEdit, onDelete } = useCountries();
    const [showForm, setShowForm] = useState(false);
    const [editing, setEditing] = useState(null);
    const [confirmDelete, setConfirmDelete] = useState(null);

    const handleAdd = () => {
        setEditing(null);
        setShowForm(true);
    };

    const handleSubmit = async (data) => {
        if (editing) {
            onEdit(editing.id, data);
        } else {
            onAdd(data);
        }
        setEditing(null);
        setShowForm(false);
    };


    const handleDelete = async () => {
        onDelete(confirmDelete.id);
        setConfirmDelete(null);
    };

    return (
        <Container sx={{ mt: 4 }}>
            <Typography variant="h4" gutterBottom>
                Manage Countries
            </Typography>
            <Button variant="contained" color="primary" onClick={handleAdd}>
                Add Country
            </Button>

            {!loading && (
                <CountryList
                    countries={countries}
                    onEdit={(item) => {
                        setEditing(item);
                        setShowForm(true);
                    }}
                    onDelete={(item) => setConfirmDelete(item)}
                />
            )}
            <CountryForm
                open={showForm}
                onClose={() => {
                    setShowForm(false);
                    setEditing(null);
                }}
                onSubmit={handleSubmit}
                initialData={editing}
            />

            <ConfirmDialog
                open={!!confirmDelete}
                title="Delete Country"
                content="Are you sure you want to delete this country?"
                onClose={() => setConfirmDelete(null)}
                onConfirm={handleDelete}
            />
        </Container>
    );
};

export default CountryPage;
