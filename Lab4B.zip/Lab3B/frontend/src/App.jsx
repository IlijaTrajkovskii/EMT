import CountryPage from "./pages/CountryPage.jsx";
import { BrowserRouter, Routes, Route } from "react-router";
import Layout from './components/layouts/Layouts.jsx';
import HomePage from "./pages/HomePage.jsx";
import HostPage from "./pages/HostPage.jsx";
import BookingPage from "./pages/BookingPage.jsx";
import LoginPage from "./pages/LoginPage.jsx";

const App = () => {
    return (
        <BrowserRouter>
            <Routes>
                <Route path="/" element={<Layout />}>
                    <Route index element={<HomePage />} />
                    <Route path="countries" element={<CountryPage />} />
                    <Route path="hosts" element={<HostPage />} />l
                    <Route path="bookings" element={<BookingPage />} />
                    <Route path="login" element={<LoginPage />} />
                </Route>
            </Routes>
        </BrowserRouter>
    );
};

export default App;
