import axiosInstance from '../axios/axios.js';

const bookingRepository = {

    findAll: async () => {
        // backend uses GET /api/bookings/listAll
        return await axiosInstance.get("/bookings/listAll");
    },

    save: async (data) => {
        // backend uses POST /api/bookings/save
        return await axiosInstance.post("/bookings/save", data);
    },

    update: async (id, data) => {
        // backend uses PUT /api/bookings/edit/{id}
        return await axiosInstance.put(`/bookings/edit/${id}`, data);
    },

    delete: async (id) => {
        // backend uses DELETE /api/bookings/delete/{id}
        return await axiosInstance.delete(`/bookings/delete/${id}`);
    },

    rent: async (id) => {
        // backend uses PUT /api/bookings/rent/{id}
        return await axiosInstance.put(`/bookings/rent/${id}`);
    }
};

export default bookingRepository;
