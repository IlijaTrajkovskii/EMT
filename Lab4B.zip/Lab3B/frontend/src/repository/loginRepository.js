import axiosInstance from "../axios/axios.js";

const loginRepository = {
    login: async (credentials) => {
        return await axiosInstance.post("/users/login", credentials);
    }
};

export default loginRepository;
