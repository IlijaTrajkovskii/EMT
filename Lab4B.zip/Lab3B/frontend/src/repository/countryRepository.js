import axiosInstance from '../axios/axios.js';

const countryRepository = {
    findAll: async () => {
        return await axiosInstance.get("/countries/listAll");
    },

    save: async (data) => {
        return await axiosInstance.post("/countries/save", data);
    },

    update: async (id, data) => {
        return await axiosInstance.put(`/countries/edit/${id}`, data);
    },

    delete: async (id) => {
        return await axiosInstance.delete(`/countries/delete/${id}`);
    }
};

export default countryRepository;
