import axiosInstance from '../axios/axios.js';

const hostRepository = {
    // GET all hosts
    findAll: async () => {
        return await axiosInstance.get("/hosts/listAll");
    },

    // POST new host
    save: async (data) => {
        return await axiosInstance.post("/hosts/save", data);
    },

    // PUT update host by ID
    update: async (id, data) => {
        return await axiosInstance.put(`/hosts/edit/${id}`, data);
    },

    // DELETE host by ID
    delete: async (id) => {
        return await axiosInstance.delete(`/hosts/delete/${id}`);
    }

};

export default hostRepository;
