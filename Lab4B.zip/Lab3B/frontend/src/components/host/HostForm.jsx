import {
    Box,
    Button,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    TextField,
    MenuItem,
    Select,
    InputLabel,
    FormControl
} from "@mui/material";
import { useState, useEffect } from "react";
import useCountries from "../../hooks/useCountries";

const HostForm = ({ open, onClose, onSubmit, initialData }) => {
    const [formData, setFormData] = useState({ name: "", surname: "", countryId: "" });
    const { countries } = useCountries();
    const [selectedCountry, setSelectedCountry] = useState("");

    useEffect(() => {
        if (initialData) {
            setFormData({
                name: initialData.name,
                surname: initialData.surname,
                countryId: initialData.countryId
            });
            setSelectedCountry(initialData.countryId);
        } else {
            setFormData({ name: "", surname: "", countryId: "" });
            setSelectedCountry("");
        }
    }, [initialData]);

    const handleChange = (e) => {
        setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
        if (e.target.name === "countryId") {
            setSelectedCountry(e.target.value);
        }
    };

    const handleSubmit = () => {
        onSubmit(formData);
        setFormData({ name: "", surname: "", countryId: "" });
        setSelectedCountry("");
    };

    return (
        <Dialog open={open} onClose={onClose}>
            <DialogTitle>{initialData ? "Edit Host" : "Add Host"}</DialogTitle>
            <DialogContent>
                <Box display="flex" flexDirection="column" gap={2} mt={1}>
                    <TextField
                        label="Name"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        fullWidth
                    />
                    <TextField
                        label="Surname"
                        name="surname"
                        value={formData.surname}
                        onChange={handleChange}
                        fullWidth
                    />
                    <FormControl fullWidth>
                        <InputLabel>Country</InputLabel>
                        <Select
                            name="countryId"
                            value={selectedCountry}
                            onChange={handleChange}
                        >
                            {countries.map((country) => (
                                <MenuItem key={country.id} value={country.id}>
                                    {country.name}
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                </Box>
            </DialogContent>
            <DialogActions>
                <Button onClick={onClose}>Cancel</Button>
                <Button onClick={handleSubmit} variant="contained" color="primary">
                    {initialData ? "Update" : "Add"}
                </Button>
            </DialogActions>
        </Dialog>
    );
};

export default HostForm;
