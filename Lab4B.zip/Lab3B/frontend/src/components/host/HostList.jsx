import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableRow,
    IconButton,
    Paper,
    TableContainer,
} from "@mui/material";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";

const HostList = ({ hosts, onEdit, onDelete }) => {
    return (
        <TableContainer component={Paper} sx={{ mt: 3 }}>
            <Table>
                <TableHead>
                    <TableRow>
                        <TableCell><b>Name</b></TableCell>
                        <TableCell><b>Surname</b></TableCell>
                        <TableCell><b>Country ID</b></TableCell>
                        <TableCell align="right"><b>Actions</b></TableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {hosts.map((host) => (
                        <TableRow key={host.id}>
                            <TableCell>{host.name}</TableCell>
                            <TableCell>{host.surname}</TableCell>
                            <TableCell>{host.countryId}</TableCell>
                            <TableCell align="right">
                                <IconButton onClick={() => onEdit(host)}>
                                    <EditIcon />
                                </IconButton>
                                <IconButton color="error" onClick={() => onDelete(host)}>
                                    <DeleteIcon />
                                </IconButton>
                            </TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </TableContainer>
    );
};

export default HostList;
