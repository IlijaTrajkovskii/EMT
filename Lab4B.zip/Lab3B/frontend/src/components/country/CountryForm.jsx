import { Box, Button, Dialog, DialogActions, DialogContent, DialogTitle, TextField } from "@mui/material";
import { useState, useEffect } from "react";

const CountryForm = ({ open, onClose, onSubmit, initialData }) => {
    const [formData, setFormData] = useState({ name: "", continent: "" });

    useEffect(() => {
        if (initialData) {
            setFormData({ name: initialData.name, continent: initialData.continent });
        } else {
            setFormData({ name: "", continent: "" });
        }
    }, [initialData]);

    const handleChange = (e) => {
        setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
    };

    const handleSubmit = () => {
        onSubmit(formData);
        setFormData({ name: "", continent: "" });
    };

    return (
        <Dialog open={open} onClose={onClose}>
            <DialogTitle>{initialData ? "Edit Country" : "Add Country"}</DialogTitle>
            <DialogContent>
                <Box display="flex" flexDirection="column" gap={2} mt={1}>
                    <TextField label="Name" name="name" value={formData.name} onChange={handleChange} fullWidth />
                    <TextField label="Continent" name="continent" value={formData.continent} onChange={handleChange} fullWidth />
                </Box>
            </DialogContent>
            <DialogActions>
                <Button onClick={onClose}>Cancel</Button>
                <Button onClick={handleSubmit} variant="contained" color="primary">
                    {initialData ? "Update" : "Add"}
                </Button>
            </DialogActions>
        </Dialog>
    );
};

export default CountryForm;
