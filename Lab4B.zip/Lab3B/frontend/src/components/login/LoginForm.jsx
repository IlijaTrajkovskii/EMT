import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import useLogin from "../../hooks/useLogin.js";
import { TextField, Button, Box, Typography, CircularProgress } from "@mui/material";

const LoginForm = () => {
    const { isAuthenticated, loading, error, login } = useLogin();
    const [credentials, setCredentials] = useState({ username: "", password: "" });
    const navigate = useNavigate();
    const handleSubmit = (e) => {
        e.preventDefault();
        login(credentials);
    };


    useEffect(() => {
        if (isAuthenticated) {
            navigate("/");
        }
    }, [isAuthenticated, navigate]);

    return (
        <Box
            sx={{
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                minHeight: '100vh',
                backgroundColor: '#f4f4f9',
            }}
        >
            <Box
                sx={{
                    width: 400,
                    padding: 4,
                    boxShadow: 3,
                    borderRadius: 2,
                    backgroundColor: 'white',
                }}
            >
                <Typography variant="h5" gutterBottom align="center">
                    Login
                </Typography>
                {loading && <CircularProgress sx={{ display: 'block', margin: '0 auto' }} />}
                {error && <Typography color="error" align="center">{error}</Typography>}
                <form onSubmit={handleSubmit}>
                    <TextField
                        fullWidth
                        label="Username"
                        variant="outlined"
                        value={credentials.username}
                        onChange={(e) => setCredentials({ ...credentials, username: e.target.value })}
                        margin="normal"
                    />
                    <TextField
                        fullWidth
                        label="Password"
                        variant="outlined"
                        type="password"
                        value={credentials.password}
                        onChange={(e) => setCredentials({ ...credentials, password: e.target.value })}
                        margin="normal"
                    />
                    <Button
                        fullWidth
                        variant="contained"
                        color="primary"
                        type="submit"
                        sx={{ marginTop: 2 }}
                        disabled={loading}
                    >
                        Login
                    </Button>
                </form>
            </Box>
        </Box>
    );
};

export default LoginForm;
