import React from 'react';
import { useNavigate } from "react-router";
import { AppBar, Box, Button, IconButton, Toolbar, Typography } from "@mui/material";
import MenuIcon from '@mui/icons-material/Menu';
import "./Header.css";

const pages = [
    { "path": "/", "name": "home" },
    { "path": "/bookings", "name": "bookings" },
    { "path": "/hosts", "name": "hosts" },
    { "path": "/countries", "name": "countries" }
];

const Header = () => {
    const navigate = useNavigate(); // Initialize the useNavigate hook

    const handleLoginClick = () => {
        navigate('/login'); // Navigate to the login page
    };

    return (
        <Box>
            <AppBar position="fixed">
                <Toolbar>
                    <IconButton
                        size="large"
                        edge="start"
                        color="inherit"
                        aria-label="menu"
                        sx={{ mr: 2 }}
                    >
                        <MenuIcon />
                    </IconButton>
                    <Typography variant="h6" component="div" sx={{ mr: 3 }}>
                        APP
                    </Typography>
                    <Box sx={{ flexGrow: 1, display: { xs: "none", md: "flex" } }}>
                        {pages.map((page) => (
                            <Button
                                key={page.name}
                                sx={{ my: 2, color: "white", display: "block" }}
                                onClick={() => navigate(page.path)} // Use navigate for routing
                            >
                                {page.name}
                            </Button>
                        ))}
                    </Box>
                    <Button color="inherit" onClick={handleLoginClick}>Login</Button>
                </Toolbar>
            </AppBar>
        </Box>
    );
};

export default Header;
