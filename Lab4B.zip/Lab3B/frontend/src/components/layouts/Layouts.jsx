import React from 'react';
import { Box, Container } from "@mui/material";
import Header from "./Header.jsx";
import { Outlet } from "react-router";
import "./Layout.css";

const Layout = () => {
    return (
        <Box className="layout-box" sx={{ display: 'flex', flexDirection: 'column', height: '100vh' }}>
            <Header />
            <Container className="outlet-container" sx={{ my: 2, pt: 10 }} maxWidth="xl">
                <Outlet />
            </Container>
        </Box>
    );
};

export default Layout;
