import {
    Button,
    Box,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    TextField,
    MenuItem,
    Select,
    InputLabel,
    FormControl,
} from "@mui/material";
import { useState, useEffect } from "react";

const BookingForm = ({ open, onClose, onSubmit, initialData, hosts }) => {


    const [formData, setFormData] = useState({
        name: "",
        category: "",
        hostId: "",
        numRooms: 0,
    });

    useEffect(() => {
        if (initialData) {
            setFormData({
                name: initialData.name,
                category: initialData.category,
                hostId: String(initialData.hostId || ""), // convert to string
                numRooms: initialData.numRooms,
            });
        } else {
            setFormData({ name: "", category: "", hostId: "", numRooms: 0 });
        }
    }, [initialData]);

    const handleChange = (e) => {
        setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
    };

    const handleSubmit = () => {
        onSubmit(formData);
        setFormData({
            name: "",
            category: "",
            hostId: "",
            numRooms: 0,
        });
    };

    const categories = ["ROOM", "HOUSE", "FLAT", "APARTMENT", "HOTEL", "MOTEL"];

    return (
        <Dialog open={open} onClose={onClose}>
            <DialogTitle>{initialData ? "Edit Booking" : "Add Booking"}</DialogTitle>
            <DialogContent>
                <Box display="flex" flexDirection="column" gap={2} mt={1}>
                    <TextField
                        label="Name"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        fullWidth
                    />
                    <FormControl fullWidth>
                        <InputLabel>Category</InputLabel>
                        <Select
                            label="Category"
                            name="category"
                            value={formData.category}
                            onChange={handleChange}
                        >
                            {categories.map((category) => (
                                <MenuItem key={category} value={category}>
                                    {category}
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                    <FormControl fullWidth>
                        <InputLabel>Host</InputLabel>
                        <Select
                            label="Host"
                            name="hostId"
                            value={formData.hostId}
                            onChange={handleChange}
                        >
                            {hosts.map((host) => (
                                <MenuItem key={host.id} value={String(host.id)}>
                                    {host.name} {host.surname}
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                    <TextField
                        label="Number of Rooms"
                        name="numRooms"
                        type="number"
                        value={formData.numRooms}
                        onChange={handleChange}
                        fullWidth
                    />
                </Box>
            </DialogContent>
            <DialogActions>
                <Button onClick={onClose}>Cancel</Button>
                <Button onClick={handleSubmit} variant="contained" color="primary">
                    {initialData ? "Update" : "Add"}
                </Button>
            </DialogActions>
        </Dialog>
    );
};

export default BookingForm;
