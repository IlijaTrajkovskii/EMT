import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableRow,
    IconButton,
    Paper,
    TableContainer,
} from "@mui/material";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";

const BookingList = ({ bookings, onEdit, onDelete }) => {
    return (
        <TableContainer component={Paper} sx={{ mt: 3 }}>
            <Table>
                <TableHead>
                    <TableRow>
                        <TableCell><b>Booking Name</b></TableCell>
                        <TableCell><b>Category</b></TableCell>
                        <TableCell><b>Host</b></TableCell>
                        <TableCell><b>Number of Rooms</b></TableCell>
                        <TableCell align="right"><b>Actions</b></TableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {bookings.map((booking) => (
                        <TableRow key={booking.id}>
                            <TableCell>{booking.name}</TableCell>
                            <TableCell>{booking.category}</TableCell>
                            <TableCell>
                                {booking.hostId}
                            </TableCell>
                            <TableCell>{booking.numRooms}</TableCell>
                            <TableCell align="right">
                                <IconButton onClick={() => onEdit(booking)}>
                                    <EditIcon />
                                </IconButton>
                                <IconButton color="error" onClick={() => onDelete(booking)}>
                                    <DeleteIcon />
                                </IconButton>
                            </TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </TableContainer>
    );
};

export default BookingList;
