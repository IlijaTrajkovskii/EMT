import { useCallback, useState } from "react";
import loginRepository from "../repository/loginRepository.js";

const initialState = {
    isAuthenticated: false,
    loading: false,
    error: null,
};

const useLogin = () => {
    const [state, setState] = useState(initialState);

    const login = useCallback((credentials) => {
        setState((prevState) => ({ ...prevState, loading: true }));
        loginRepository
            .login(credentials)
            .then((response) => {
                localStorage.setItem("jwtToken", response.data.token); // Store the JWT token
                setState({
                    isAuthenticated: true,
                    loading: false,
                    error: null,
                });
                console.log("Login successful");
            })
            .catch((error) => {
                setState({
                    isAuthenticated: false,
                    loading: false,
                    error: error.response ? error.response.data.message : "Login failed",
                });
                console.error("Login failed:", error);
            });
    }, []);

    return { ...state, login };
};

export default useLogin;
