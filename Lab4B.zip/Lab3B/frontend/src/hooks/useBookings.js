import bookingRepository from "../repository/bookingRepository.js";
import { useCallback, useEffect, useState } from "react";

const initialState = { bookings: [], loading: true}

const useBookings = () => {
    const [state, setState] = useState(initialState);

    const fetchBookings = useCallback(() => {
        bookingRepository.findAll()
            .then((response) => {
                setState({
                    bookings: response.data,
                    loading: false
                });
            })
            .catch((error) => {
                console.log("Failed to fetch bookings: ", error);
            });
    }, []);

    const onAdd = useCallback((data) => {
        bookingRepository.save(data)
            .then(() => {
                console.log("Successfully added a new booking");
                fetchBookings();
            })
            .catch((error) => {
                console.log("Failed to add new booking: ", error);
            });
    }, [fetchBookings]);

    const onEdit = useCallback((id, data) => {
        bookingRepository.update(id, data)
            .then(() => {
                console.log("Successfully updated a booking");
                fetchBookings();
            })
            .catch((error) => {
                console.log("Failed to update booking: ", error);
            });
    }, [fetchBookings]);

    const onDelete = useCallback((id) => {
        bookingRepository.delete(id)
            .then(() => {
                console.log("Successfully deleted a booking");
                fetchBookings();
            })
            .catch((error) => {
                console.log("Failed to delete booking: ", error);
            });
    }, [fetchBookings]);

    useEffect(() => {
        fetchBookings();
    }, [fetchBookings]);

    return {
        ...state,
        onAdd,
        onEdit,
        onDelete
    };
}

export default useBookings;
