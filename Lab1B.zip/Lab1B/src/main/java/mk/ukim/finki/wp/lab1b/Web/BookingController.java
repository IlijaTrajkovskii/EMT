package mk.ukim.finki.wp.lab1b.Web;


import mk.ukim.finki.wp.lab1b.Model.Booking;
import mk.ukim.finki.wp.lab1b.Model.DTO.BookingDTO;
import mk.ukim.finki.wp.lab1b.Model.DTO.EditBookingDTO;
import mk.ukim.finki.wp.lab1b.Service.BookingService;
import mk.ukim.finki.wp.lab1b.Service.HostService;
import org.apache.coyote.Response;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {

    private final BookingService bookingService;
    private final HostService hostService;

    public BookingController(BookingService bookingService, HostService hostService) {
        this.bookingService = bookingService;
        this.hostService = hostService;
    }

    @GetMapping("/listAll")
    public ResponseEntity<List<Booking>> listAll(){

        return ResponseEntity.ok(bookingService.getAllBookings());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Booking> findById(@PathVariable Long id) throws Exception {

        return ResponseEntity.ok(bookingService.findById(id).orElseThrow(Exception::new));


        


    }

    @PostMapping("/save")
    public ResponseEntity<Booking> save(@RequestBody BookingDTO bookingDTO) throws Exception {

        return ResponseEntity.ok(bookingService.save(bookingDTO).orElseThrow(Exception::new));

    }

    @PutMapping("/edit/{id}")
    public ResponseEntity<Booking> update(@PathVariable Long id, @RequestBody EditBookingDTO editBookingDTO) throws Exception {

        return ResponseEntity.ok(bookingService.update(id,editBookingDTO).orElseThrow(Exception::new));

    }

    @PutMapping("/rent/{id}")
    public ResponseEntity<Booking> rent(@PathVariable Long id) throws Exception {

        bookingService.rented(id);

        return ResponseEntity.noContent().build();

    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) throws Exception {

        bookingService.deleteById(id);
        return ResponseEntity.noContent().build();
    }





}
