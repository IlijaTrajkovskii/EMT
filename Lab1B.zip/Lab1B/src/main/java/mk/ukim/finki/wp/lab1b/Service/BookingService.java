package mk.ukim.finki.wp.lab1b.Service;

import mk.ukim.finki.wp.lab1b.Model.Booking;
import mk.ukim.finki.wp.lab1b.Model.DTO.BookingDTO;
import mk.ukim.finki.wp.lab1b.Model.DTO.EditBookingDTO;

import java.util.List;
import java.util.Optional;

public interface BookingService {

    List<Booking> getAllBookings();
    Optional<Booking> findById(Long id);

    Optional<Booking> update(Long id, EditBookingDTO editBookingDTO) throws Exception;

    Optional<Booking> save(BookingDTO bookingDTO) throws Exception;

    void deleteById(Long id);

    void rented(Long id) throws Exception;


}
