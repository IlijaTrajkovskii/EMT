package mk.ukim.finki.wp.lab1b.Service;

import mk.ukim.finki.wp.lab1b.Model.Country;

import java.util.List;
import java.util.Optional;

public interface CountryService {

    List<Country> getAllCountries();
    Optional<Country> findById(Long id);
}
