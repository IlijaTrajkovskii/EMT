package mk.ukim.finki.wp.lab1b.Service.impl;


import mk.ukim.finki.wp.lab1b.Model.Booking;
import mk.ukim.finki.wp.lab1b.Model.DTO.BookingDTO;
import mk.ukim.finki.wp.lab1b.Model.DTO.EditBookingDTO;
import mk.ukim.finki.wp.lab1b.Model.Hosts;
import mk.ukim.finki.wp.lab1b.Repository.BookingRepository;
import mk.ukim.finki.wp.lab1b.Repository.HostsRepository;
import mk.ukim.finki.wp.lab1b.Service.BookingService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BookingServiceImpl implements BookingService {

    private final BookingRepository bookingRepository;
    private final HostsRepository hostsRepository;

    public BookingServiceImpl(BookingRepository bookingRepository, HostsRepository hostsRepository) {
        this.bookingRepository = bookingRepository;
        this.hostsRepository = hostsRepository;
    }

    @Override
    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }


    @Override
    public Optional<Booking> findById(Long id) {
        return bookingRepository.findById(id);
    }

    @Override
    public Optional<Booking> save(BookingDTO bookingDTO) throws Exception {

        Hosts host = hostsRepository.findById(bookingDTO.getHostId()).orElseThrow(Exception::new);

        Booking booking = new Booking(bookingDTO.getName(),bookingDTO.getCategory(),host,bookingDTO.getNumRooms());

        bookingRepository.save(booking);

        return Optional.of(booking);
    }

    @Override
    public Optional<Booking> update(Long id, EditBookingDTO editBookingDTO) throws Exception {

        Booking booking = bookingRepository.findById(id).orElseThrow(Exception::new);
        Hosts host = hostsRepository.findById(editBookingDTO.getHostId()).orElseThrow(Exception::new);

        booking.setName(editBookingDTO.getName());
        booking.setCategory(editBookingDTO.getCategory());
        booking.setHosts(host);
        booking.setNumRooms(editBookingDTO.getNumRooms());
        booking.setRented(editBookingDTO.getRented());

        bookingRepository.save(booking);

        return Optional.of(booking);

    }

    @Override
    public void deleteById(Long id) {

        bookingRepository.deleteById(id);

    }

    @Override
    public void rented(Long id) throws Exception {

        Booking booking = bookingRepository.findById(id).orElseThrow(Exception::new);

        booking.setRented(true);

        bookingRepository.save(booking);
    }
}
