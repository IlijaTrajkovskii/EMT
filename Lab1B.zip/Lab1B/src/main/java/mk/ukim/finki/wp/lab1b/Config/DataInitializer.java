package mk.ukim.finki.wp.lab1b.Config;


import jakarta.annotation.PostConstruct;
import mk.ukim.finki.wp.lab1b.Model.Country;
import mk.ukim.finki.wp.lab1b.Model.Hosts;
import mk.ukim.finki.wp.lab1b.Repository.BookingRepository;
import mk.ukim.finki.wp.lab1b.Repository.CountryRepository;
import mk.ukim.finki.wp.lab1b.Repository.HostsRepository;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer {

    private final HostsRepository hostsRepository;
    private final CountryRepository countryRepository;


    public DataInitializer(HostsRepository hostsRepository, CountryRepository countryRepository) {
        this.hostsRepository = hostsRepository;
        this.countryRepository = countryRepository;
    }

    @PostConstruct
    public void DataInit() {
        Country macedonia = new Country( "Macedonia", "Europe");
        Country usa = new Country( "USA", "North America");

       countryRepository.save(macedonia);
       countryRepository.save(usa);

        hostsRepository.save(new Hosts( "Ivan", "Ivanov", macedonia));
        hostsRepository.save(new Hosts( "John", "Doe", usa));
    }


}
