package mk.ukim.finki.wp.lab1b.Repository;

import mk.ukim.finki.wp.lab1b.Model.Country;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CountryRepository extends JpaRepository<Country, Long> {
}
