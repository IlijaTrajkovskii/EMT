package mk.ukim.finki.wp.lab1b.Model;

public enum Category {
    ROOM,
    HOUSE,
    FLAT,
    APARTMENT,
    HOTEL,
    MOTEL
}
