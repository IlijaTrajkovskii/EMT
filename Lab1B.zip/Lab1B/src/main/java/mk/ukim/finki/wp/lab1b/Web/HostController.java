package mk.ukim.finki.wp.lab1b.Web;


import mk.ukim.finki.wp.lab1b.Model.Hosts;
import mk.ukim.finki.wp.lab1b.Service.HostService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/hosts")
public class HostController {


    private final HostService hostService;

    public HostController(HostService hostService) {
        this.hostService = hostService;
    }

    @GetMapping("/listAll")
    public List<Hosts> findAll()
    {
        return hostService.getAllHosts();
    }

}
