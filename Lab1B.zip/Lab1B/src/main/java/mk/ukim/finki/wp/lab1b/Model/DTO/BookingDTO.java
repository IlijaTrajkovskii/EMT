package mk.ukim.finki.wp.lab1b.Model.DTO;

import jakarta.persistence.ManyToOne;
import mk.ukim.finki.wp.lab1b.Model.Category;
import mk.ukim.finki.wp.lab1b.Model.Hosts;

public class BookingDTO {

    private String name;
    private Category category;
    private Long hostId;
    private Integer numRooms;


    // definirame i ostanati komponetnti construktori i getteri settteri za da mozeme da gi dobivame vrednostite preku DTO objektot!


    public BookingDTO() {
    }

    public BookingDTO(String name, Category category, Long hostId, Integer numRooms) {
        this.name = name;
        this.category = category;
        this.hostId = hostId;
        this.numRooms = numRooms;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public Long getHostId() {
        return hostId;
    }

    public void setHostId(Long hostId) {
        this.hostId = hostId;
    }

    public Integer getNumRooms() {
        return numRooms;
    }

    public void setNumRooms(Integer numRooms) {
        this.numRooms = numRooms;
    }
}
