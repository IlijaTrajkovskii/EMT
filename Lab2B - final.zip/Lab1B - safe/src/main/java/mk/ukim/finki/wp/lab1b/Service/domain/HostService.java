package mk.ukim.finki.wp.lab1b.Service.domain;

import mk.ukim.finki.wp.lab1b.Model.domain.Hosts;

import java.util.List;
import java.util.Optional;

public interface HostService {

    List<Hosts> getAllHosts();
    Optional<Hosts> findById(Long id);
}
