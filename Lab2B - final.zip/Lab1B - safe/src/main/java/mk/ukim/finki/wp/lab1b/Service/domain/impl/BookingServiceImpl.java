package mk.ukim.finki.wp.lab1b.Service.domain.impl;


import mk.ukim.finki.wp.lab1b.Model.domain.Booking;
import mk.ukim.finki.wp.lab1b.Model.domain.Hosts;
import mk.ukim.finki.wp.lab1b.Repository.BookingRepository;
import mk.ukim.finki.wp.lab1b.Repository.HostsRepository;
import mk.ukim.finki.wp.lab1b.Service.domain.BookingService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BookingServiceImpl implements BookingService {

    private final BookingRepository bookingRepository;
    private final HostsRepository hostsRepository;

    public BookingServiceImpl(BookingRepository bookingRepository, HostsRepository hostsRepository) {
        this.bookingRepository = bookingRepository;
        this.hostsRepository = hostsRepository;
    }

    @Override
    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }


    @Override
    public Optional<Booking> findById(Long id) {
        return bookingRepository.findById(id);
    }

    @Override
    public Optional<Booking> save(Booking booking) throws Exception {

        Hosts host = hostsRepository.findById(booking.getHosts().getId()).orElseThrow(Exception::new);

        Booking accommodation = new Booking(booking.getName(),booking.getCategory(),host, booking.getNumRooms());

        bookingRepository.save(booking);

        return Optional.of(booking);
    }

    @Override
    //id za da znaeme koj booking da go editirame, i booking objekt za da samiot update info
    public Optional<Booking> update(Long id, Booking booking) throws Exception {

        Booking accommodation = bookingRepository.findById(id).orElseThrow(Exception::new);
        Hosts host = hostsRepository.findById(booking.getHosts().getId()).orElseThrow(Exception::new);

        accommodation.setName(booking.getName());
        accommodation.setCategory(booking.getCategory());
        accommodation.setHosts(host);
        accommodation.setNumRooms(booking.getNumRooms());
        accommodation.setRented(booking.getRented());

        bookingRepository.save(accommodation);

        return Optional.of(accommodation);

    }

    @Override
    public void deleteById(Long id) {

        bookingRepository.deleteById(id);

    }

    @Override
    public void rented(Long id) throws Exception {

        Booking booking = bookingRepository.findById(id).orElseThrow(Exception::new);

        booking.setRented(true);

        bookingRepository.save(booking);
    }
}
