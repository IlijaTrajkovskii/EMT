package mk.ukim.finki.wp.lab1b.Service.application.impl;


import mk.ukim.finki.wp.lab1b.DTO.CreateBookingDto;
import mk.ukim.finki.wp.lab1b.DTO.DisplayBookingDto;
import mk.ukim.finki.wp.lab1b.DTO.DisplayHostDto;
import mk.ukim.finki.wp.lab1b.Model.domain.Booking;
import mk.ukim.finki.wp.lab1b.Model.domain.Hosts;
import mk.ukim.finki.wp.lab1b.Repository.BookingRepository;
import mk.ukim.finki.wp.lab1b.Repository.HostsRepository;
import mk.ukim.finki.wp.lab1b.Service.application.BookingApplicationService;
import mk.ukim.finki.wp.lab1b.Service.domain.BookingService;
import mk.ukim.finki.wp.lab1b.Service.domain.HostService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BookingApplicationServiceImpl implements BookingApplicationService {

    private final BookingService bookingService;
    private final HostService hostService;

    public BookingApplicationServiceImpl(BookingService bookingService, HostService hostService) {
        this.bookingService = bookingService;
        this.hostService = hostService;
    }

    @Override
    public List<DisplayBookingDto> getAllBookings() {

        return bookingService.getAllBookings().stream().map(DisplayBookingDto::fromBooking).toList();
    }


    @Override
    public Optional<DisplayBookingDto> findById(Long id) {
        return bookingService.findById(id).map(DisplayBookingDto::fromBooking);
    }

    @Override
    public Optional<DisplayBookingDto> save(CreateBookingDto createBookingDto) throws Exception {

        // samo ja dirigira, ili predava rabotata na domenskiot sloj
       Optional<Hosts> host = hostService.findById(createBookingDto.hostId());

       if (host.isPresent()) {

           return bookingService.save(createBookingDto.toBooking(host.get())).map(DisplayBookingDto::fromBooking);
       }
       return Optional.empty();

    }

    @Override
    public Optional<DisplayBookingDto> update(Long id, CreateBookingDto createBookingDto) throws Exception {

        Optional<Hosts> host = hostService.findById(id);

        return bookingService.update(id,createBookingDto.toBooking(host.orElse(null))).map(DisplayBookingDto::fromBooking);

    }

    @Override
    public void deleteById(Long id) {

        bookingService.deleteById(id);

    }

    @Override
    public void rented(Long id) throws Exception {

        bookingService.rented(id);
    }
}
