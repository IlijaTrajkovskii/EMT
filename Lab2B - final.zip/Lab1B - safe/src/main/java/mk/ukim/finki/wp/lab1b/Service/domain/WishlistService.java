package mk.ukim.finki.wp.lab1b.Service.domain;

import mk.ukim.finki.wp.lab1b.Model.domain.Booking;
import mk.ukim.finki.wp.lab1b.Model.domain.Wishlist;

import java.awt.print.Book;
import java.util.List;
import java.util.Optional;

public interface WishlistService {

    List<Booking> listAllBookingsInWishlist(Long wishlistId);

    Optional<Wishlist> getActiveWishlist(String username);

    Optional<Wishlist> addBookingToWishlist(String username, Long bookingId);
}
