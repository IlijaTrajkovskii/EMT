package mk.ukim.finki.wp.lab1b.Web;


import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import mk.ukim.finki.wp.lab1b.DTO.DisplayBookingDto;
import mk.ukim.finki.wp.lab1b.DTO.DisplayHostDto;
import mk.ukim.finki.wp.lab1b.Model.domain.Hosts;
import mk.ukim.finki.wp.lab1b.Service.application.HostApplicationService;
import mk.ukim.finki.wp.lab1b.Service.application.impl.HostApplicationServiceImpl;
import mk.ukim.finki.wp.lab1b.Service.domain.HostService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/hosts")
@Tag(name = "Host API", description = "Endpoints for managing HOSTS")
public class HostController {


    private final HostApplicationService hostApplicationService;

    public HostController(HostApplicationService hostApplicationService) {
        this.hostApplicationService = hostApplicationService;
    }


    @Operation(summary = "Get all hosts", description = "Retrieves a list of all the hosts")
    @GetMapping("/listAll")
    public ResponseEntity<List<DisplayHostDto>> listAll(){

        return ResponseEntity.ok(hostApplicationService.getAllHosts());
    }

}
