package mk.ukim.finki.wp.lab1b.Model.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.PRECONDITION_FAILED)
public class BookingAlreadyInWishlistException extends RuntimeException{

    public BookingAlreadyInWishlistException(Long id, String username) {
        super(String.format("Booking with id: %d already exists in wishlist for user with username %s", id, username));
    }
}

