package mk.ukim.finki.wp.lab1b.Service.application.impl;

import mk.ukim.finki.wp.lab1b.DTO.DisplayBookingDto;
import mk.ukim.finki.wp.lab1b.DTO.DisplayUserDto;
import mk.ukim.finki.wp.lab1b.DTO.WishlistDto;
import mk.ukim.finki.wp.lab1b.Service.application.WishlistApplicationService;
import mk.ukim.finki.wp.lab1b.Service.domain.WishlistService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class WishlistApplicationServiceImpl implements WishlistApplicationService {

    private final WishlistService wishlistService;

    public WishlistApplicationServiceImpl(WishlistService wishlistService) {
        this.wishlistService = wishlistService;
    }

    @Override
    public List<DisplayBookingDto> listAllBookingsInWishlist(Long wishlistId) {
        return DisplayBookingDto.fromBooking(wishlistService.listAllBookingsInWishlist(wishlistId));

    }

    @Override
    public Optional<WishlistDto> getActiveWishlist(String username) {
        return wishlistService.getActiveWishlist(username).map(WishlistDto::fromWishlist);
    }

    @Override
    public Optional<WishlistDto> addBookingToWishlist(String username, Long bookingId) {
        return wishlistService.addBookingToWishlist(username, bookingId).map(WishlistDto::fromWishlist);
    }
}
