package mk.ukim.finki.wp.lab1b.Service.application;

import mk.ukim.finki.wp.lab1b.DTO.DisplayCountryDto;
import mk.ukim.finki.wp.lab1b.Model.domain.Country;

import java.util.List;
import java.util.Optional;

public interface CountryApplicationService {

    List<DisplayCountryDto> getAllCountries();
    Optional<DisplayCountryDto> findById(Long id);
}
